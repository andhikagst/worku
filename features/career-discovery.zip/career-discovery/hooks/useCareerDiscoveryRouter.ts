import { useCallback } from "react";
import { useRouter } from "next/navigation";
import { archetypes } from "../data/archetypes";

const STORAGE_KEY = "career_discovery_scores";

export const useCareerDiscoveryRouter = () => {
  const router = useRouter();

  const saveScores = useCallback((scores: Record<string, number>) => {
    if (typeof window === "undefined") return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(scores));
  }, []);

  const loadScores = useCallback((): Record<string, number> => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : {
        strategic_analyst: 0,
        creative_architect: 0,
        people_first_leader: 0,
        relentless_builder: 0,
        human_connector: 0,
        curious_pioneer: 0,
      };
    } catch {
      return { strategic_analyst: 0, creative_architect: 0, people_first_leader: 0, relentless_builder: 0, human_connector: 0,
        curious_pioneer: 0 };
    }
  }, []);

  const clearScores = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const goToQuestion = useCallback((step: number) => {
    router.push(`/career-discovery/question?step=${step}`);
  }, [router]);

  const goToResult = useCallback(() => {
    router.push("/career-discovery/result");
  }, [router]);

  const goToRoadmap = useCallback(() => {
    router.push("/career-discovery/roadmap");
  }, [router]);

  const retake = useCallback(() => {
    clearScores();
    router.push("/career-discovery/question?step=1");
  }, [router, clearScores]);

  const getRankedArchetypes = useCallback(() => {
  const scores = loadScores();
  const total = Object.values(scores).reduce((a, b) => a + b, 0);

  return Object.entries(scores)
    .sort((a, b) => b[1] - a[1])
    .map(([id, score]) => ({
      archetype: archetypes[id],
      score,
      percentage: total > 0 ? Math.round((score / total) * 100) : 0,
    }));
}, [loadScores]);

  return { saveScores, loadScores, clearScores, goToQuestion, goToResult, goToRoadmap, retake, getRankedArchetypes };
};