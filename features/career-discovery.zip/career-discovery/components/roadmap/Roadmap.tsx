"use client";
import { useEffect, useState } from "react";
import { archetypes } from "@/features/career-discovery/data/archetypes";
import { Archetype } from "@/features/career-discovery/types/career-discovery.types";
import { useCareerDiscoveryRouter } from "@/features/career-discovery/hooks/useCareerDiscoveryRouter";
import { Button } from "@/shared/components/UI/button/Button";
import { useRouter } from "next/navigation";

const typeColors: Record<string, string> = {
  Foundation: "bg-green-100 text-green-700",
  Skill: "bg-blue-100 text-blue-700",
  Project: "bg-purple-100 text-purple-700",
  "Career Action": "bg-pink-100 text-pink-700",
  Milestone: "bg-yellow-100 text-yellow-700",
};

const RoadmapPage = () => {
  const [result, setResult] = useState<Archetype | null>(null);
  const { loadScores, retake } = useCareerDiscoveryRouter();
  const router = useRouter();

  useEffect(() => {
    const scores = loadScores();
    const allZero = Object.values(scores).every((v) => v === 0);

    if (allZero) {
      router.replace("/career-discovery");
      return;
    }

    const topId = Object.entries(scores).sort((a, b) => b[1] - a[1])[0][0];
    setResult(archetypes[topId]);
  }, []);

  if (!result) return (
    <div className="min-h-screen flex items-center justify-center">
      <p className="text-gray-500">Loading roadmap...</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-16 px-20 lg:pt-34.25 pt-28">
      {/* Header */}
      <div className="mb-10">
        <h1 className="text-4xl font-bold text-teal-900">{result.title}</h1>
        <p className="text-teal-600 mt-1">{result.subtitle}</p>
        <p className="text-gray-500 mt-3 max-w-2xl">{result.description}</p>
        <div className="flex gap-2 mt-4 flex-wrap">
          {result.traits.map((t) => (
            <span key={t} className="px-3 py-1 rounded-full border border-gray-300 text-sm text-gray-600">{t}</span>
          ))}
        </div>
        <div className="flex gap-3 mt-6">
          <Button variant="primary" size="default" className="bg-teal-700">Start My Roadmap</Button>
          <Button variant="primary" size="default" onClick={retake} className="bg-gray-200 text-gray-700">Retake Discovery</Button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex gap-3 mb-10 flex-wrap">
        {Object.entries(typeColors).map(([type, color]) => (
          <span key={type} className={`px-3 py-1 rounded-full text-xs font-medium ${color}`}>{type}</span>
        ))}
      </div>

      {/* Timeline */}
      <div className="flex flex-col gap-10 relative">
        <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-teal-200" />
        {result.roadmap.map((phase, pi) => (
          <div key={pi} className="pl-12 relative">
            <div className="absolute left-2 top-3 w-4 h-4 rounded-full bg-teal-600 border-2 border-white shadow" />
            <div className="flex items-center justify-between bg-teal-700 text-white px-6 py-4 rounded-xl mb-4">
              <div>
                <p className="text-xs uppercase tracking-widest text-teal-200">— {phase.phase} —</p>
                <h3 className="text-lg font-bold mt-0.5">{phase.label}</h3>
                <p className="text-sm text-teal-200 mt-1">{phase.description}</p>
              </div>
              <span className="text-sm text-teal-200 shrink-0 ml-6">{phase.duration}</span>
            </div>
            <div className="grid grid-cols-3 gap-4">
              {phase.items.map((item, ii) => (
                <div key={ii} className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm flex flex-col gap-2">
                  <h4 className="font-semibold text-teal-900 text-sm">{item.title}</h4>
                  <p className="text-xs text-gray-500">{item.description}</p>
                  <div className="flex items-center justify-between mt-auto pt-2">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${typeColors[item.type]}`}>
                      {item.type}
                    </span>
                    <span className="text-xs text-gray-400">{item.duration}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RoadmapPage;