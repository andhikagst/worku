import { Archetype } from "../types/career-discovery.types";

export const archetypes: Record<string, Archetype> = {
  strategic_analyst: {
    id: "strategic_analyst",
    title: "The Strategic Analyst",
    subtitle: "Data · Research · Product Intelligence",
    icon: "🔍",
    roles: ["Data Analyst", "UX Researcher", "Product Analyst"],
    description:
      "You find clarity in complexity. You ask better questions than most people have answers for, and your decisions are firmly anchored in evidence. You're the person others turn to when things don't add up.",
    traits: ["Data-driven", "Rigorous", "Detail-oriented", "Evidence-based", "Systematic"],
    roadmap: [
      {
        phase: "FOUNDATION",
        label: "Establish your baseline",
        duration: "Now – 3 months",
        description: "Audit your current skills, complete your WorkU profile, and dive into your top recommended course.",
        items: [
          { title: "Complete Career Discovery", description: "Confirm Strategic Analyst archetype", type: "Foundation", duration: "30 min" },
          { title: "Python & Pandas Foundations", description: "DataFrames, cleaning, group by, merging", type: "Skill", duration: "8 hrs" },
          { title: "SQL – Basics to Window Functions", description: "Joins, CTEs, window functions, query optimization", type: "Skill", duration: "8 hrs" },
          { title: "Milestone: Analytical Baseline Set", description: "Python + SQL working. Specialization chosen.", type: "Milestone", duration: "End of month 3" },
        ],
      },
      {
        phase: "BUILD",
        label: "Close your skill gaps",
        duration: "3 – 6 months",
        description: "Deep-dive into your primary discipline. Build one portfolio project that demonstrates your profile's core strength.",
        items: [
          { title: "Statistics That Actually Matter", description: "Distributions, hypothesis testing, p-values", type: "Skill", duration: "8 hrs" },
          { title: "Portfolio Project #1 – Full Analysis", description: "End-to-end: question → data → analysis → recommendation", type: "Project", duration: "2 weeks" },
          { title: "Milestone: Data Portfolio Live", description: "2 notebook projects on GitHub. Kaggle profile active.", type: "Milestone", duration: "End of month 6" },
        ],
      },
    ],
  },
  creative_architect: {
    id: "creative_architect",
    title: "The Creative Architect",
    subtitle: "Design · Visual Systems · UX Strategy",
    icon: "✂️",
    roles: ["Senior UI/UX", "Design Lead", "Head of Design"],
    description:
      "You combine aesthetic sensibility with systems thinking. You see the world as a series of experiences waiting to be designed — and you build things people love to use. Your work is felt before it's explained.",
    traits: ["Visually fluent", "Iterative", "Systems thinker", "Quality-obsessed", "User empathy"],
    roadmap: [
      {
        phase: "FOUNDATION",
        label: "Build your design foundation",
        duration: "Now – 3 months",
        description: "Master the fundamentals of design thinking and core tools.",
        items: [
          { title: "UI Design Principles", description: "Typography, color, hierarchy", type: "Skill", duration: "8 hrs" },
          { title: "Figma Mastery", description: "Components, auto layout, prototyping", type: "Skill", duration: "10 hrs" },
          { title: "Milestone: First Portfolio Piece", description: "One end-to-end UI case study published", type: "Milestone", duration: "End of month 3" },
        ],
      },
    ],
  },
  people_first_leader: {
    id: "people_first_leader",
    title: "The People-First Leader",
    subtitle: "Product Management · Leadership · Strategy",
    icon: "🎯",
    roles: ["Product Manager", "Head of Product", "Engineering Manager"],
    description:
      "You multiply other's output. You're energized by building conditions for great work — aligning, unblocking, and helping talented people thrive.",
    traits: ["Empathetic", "Visionary", "Decisive", "Trusted", "Organized"],
    roadmap: [
      {
        phase: "FOUNDATION",
        label: "Build leadership foundations",
        duration: "Now – 3 months",
        description: "Develop core product and leadership skills.",
        items: [
          { title: "Product Management 101", description: "Roadmaps, PRDs, stakeholder management", type: "Skill", duration: "10 hrs" },
          { title: "Milestone: First Product Spec", description: "Write and present one full PRD", type: "Milestone", duration: "End of month 3" },
        ],
      },
    ],
  },
  relentless_builder: {
    id: "relentless_builder",
    title: "The Relentless Builder",
    subtitle: "Engineering · Fullstack · Technical Product",
    icon: "⚡",
    roles: ["Software Engineer", "Technical PM", "Fullstack Developer"],
    description:
      "You ship. Where others plan, you create. You have a deep bias for action and real satisfaction in seeing something go from zero to live. Problems energize you because every problem is a construction project.",
    traits: ["Fast-moving", "Technical", "Hands-on", "Execution-focused", "Resourceful"],
    roadmap: [
      {
        phase: "FOUNDATION",
        label: "Stack your technical skills",
        duration: "Now – 3 months",
        description: "Pick your stack and start shipping real projects.",
        items: [
          { title: "Fullstack Fundamentals", description: "HTML, CSS, JS, React basics", type: "Skill", duration: "12 hrs" },
          { title: "Milestone: First Deployed App", description: "One live project on Vercel or Netlify", type: "Milestone", duration: "End of month 3" },
        ],
      },
    ],
  },
  human_connector: {
    id: "human_connector",
    title: "The Human Connector",
    subtitle: "Community · Growth · People Operations",
    icon: "⚡",
    roles: ["Growth Manager", "Community Lead", "Partnership Manager"],
    description:
      "You build the relationships that build everything else. You're the multiplier in the room — bringing the right people together, creating trust where there was none, and growing things through genuine human connection.",
    traits: ["Empathetic", "Persuasive", "Network-builder", "Culturally fluent", "Communicator"],
    roadmap: [
      {
        phase: "FOUNDATION",
        label: "Stack your technical skills",
        duration: "Now – 3 months",
        description: "Pick your stack and start shipping real projects.",
        items: [
          { title: "Fullstack Fundamentals", description: "HTML, CSS, JS, React basics", type: "Skill", duration: "12 hrs" },
          { title: "Milestone: First Deployed App", description: "One live project on Vercel or Netlify", type: "Milestone", duration: "End of month 3" },
        ],
      },
    ],
  },
  curious_pioneer: {
    id: "the_curious_pioneer",
    title: "The Curious Pioneer",
    subtitle: "Entrepreneurship · Innovation · Venture",
    icon: "⚡",
    roles: ["Founder", "Venture Analyst", "Innovation Lead"],
    description:
      "You look at the world and see what doesn't exist yet. You're comfortable with deep uncertainty and energized by white space.",
    traits: ["Risk-tolerant", "Visionary", "Experimentalr", "Self-directed", "First-principles"],
    roadmap: [
      {
        phase: "FOUNDATION",
        label: "Stack your technical skills",
        duration: "Now – 3 months",
        description: "Pick your stack and start shipping real projects.",
        items: [
          { title: "Fullstack Fundamentals", description: "HTML, CSS, JS, React basics", type: "Skill", duration: "12 hrs" },
          { title: "Milestone: First Deployed App", description: "One live project on Vercel or Netlify", type: "Milestone", duration: "End of month 3" },
        ],
      },
    ],
  },
};